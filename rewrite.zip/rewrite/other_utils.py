import bpy
import bmesh
import numpy as np
import mathutils
from scipy.optimize import linear_sum_assignment

# selects all vertices that are inside the convex hull of selected faces
def select_faces_inside_convex_hull(bm, verts, bm_original):
    # deselect all geometry
    for geom in bm.verts[:] + bm.edges[:] + bm.faces[:]:
        geom.select_set(False)
    for geom in bm_original.verts[:] + bm_original.edges[:] + bm_original.faces[:]:
        geom.select_set(False)

    #  generate convex hull of selected faces
    hull = bmesh.ops.convex_hull(bm, input=verts, use_existing_faces=True)


    # delete all geometry that is not part of the convex hull
    not_selected = [vert for vert in bm.verts[:] if not vert.select]
    bmesh.ops.delete(bm, geom=not_selected, context="VERTS")
            
    # build BVH tree of convex hull
    bvh = mathutils.bvhtree.BVHTree.FromBMesh(bm)

    # select faces on original bmesh that are inside the convex hull
    # use raycasting in BVH tree to check normals
    for face in bm_original.faces:

        # get center of face
        center = face.calc_center_median()
        # get normal of face
        normal = face.normal
        
        # raycast in BVH tree
        hit, hit_normal, face_index, distance = bvh.ray_cast(center, normal)

        if hit is None:
            hit, hit_normal, face_index, distance = bvh.ray_cast(center, -normal)

        
        # if normal is negative, face is inside the convex hull
        if hit is not None and (hit_normal.dot(normal) > 0 or distance < 0.0001):
            face.select_set(True)
            # print("hit:", hit)
            # print("hit_normal:", hit_normal)
            # print("face_index:", face_index)
            # print("distance:", distance)
            # print("normal:", normal)
            # print(hit_normal.dot(normal))

# from two edges returns closest vertex for each edge
def closest_vertices(edge1, edge2):
    # get vertices of the two edges
    vert1 = edge1.verts[0]
    vert2 = edge1.verts[1]
    vert3 = edge2.verts[0]
    vert4 = edge2.verts[1]

    # get distance between vertices
    dist1 = np.linalg.norm(np.array(vert1.co) - np.array(vert3.co))
    dist2 = np.linalg.norm(np.array(vert1.co) - np.array(vert4.co))
    dist3 = np.linalg.norm(np.array(vert2.co) - np.array(vert3.co))
    dist4 = np.linalg.norm(np.array(vert2.co) - np.array(vert4.co))

    # get index of the two vertices that are closest to each other
    index1 = np.argmin([dist1, dist2, dist3, dist4])

    # return vertices
    if index1 == 0:
        return vert1, vert3
    elif index1 == 1:
        return vert1, vert4
    elif index1 == 2:
        return vert2, vert3
    elif index1 == 3:
        return vert2, vert4


# calculates weight of how good would be edge between two vertices
def edge_similarity_weight(edge1, edge2, avg_dist, avg_direction):
    # higher weight is better

    # get vectors of the two edges
    edge1_vec = (edge1.verts[0].co - edge1.verts[1].co)/np.linalg.norm(edge1.verts[0].co - edge1.verts[1].co)
    edge2_vec = (edge2.verts[0].co - edge2.verts[1].co)/np.linalg.norm(edge2.verts[0].co - edge2.verts[1].co)
    
    # get closest vertices
    vert1, vert2 = closest_vertices(edge1, edge2)

    # check if distance is too small
    dist = np.linalg.norm(np.array(vert1.co) - np.array(vert2.co))
    if dist < 0.0001:
        return 0, 0, 0

    # edge 3 - edge between vert1 and vert2
    edge3_vec = (vert1.co - vert2.co)/np.linalg.norm(vert1.co - vert2.co)

    # get angle offset of edges
    angle = np.abs(np.dot(edge1_vec, edge3_vec)) + np.abs(np.dot(edge2_vec, edge3_vec))

    # get distance between vertices
    dist = np.linalg.norm(np.array(vert1.co) - np.array(vert2.co))

    # get angle offset from average vector
    # normalise the resulting vector
    avg_angle_diff = np.abs(np.dot(avg_direction, edge3_vec))
    if avg_angle_diff < 0.5:
        # if less than 0.5, they are closer to perpendicular
        avg_angle_diff = 1 - avg_angle_diff

    # get weight
    weight = angle * avg_angle_diff**2 #/ (dist + avg_dist)

    return weight, vert1, vert2


