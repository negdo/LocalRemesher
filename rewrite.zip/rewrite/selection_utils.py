import bpy
import bmesh
import numpy as np
import mathutils

# returns selected faces and their vertices
def get_selected(bm):
    faces_selected = [face for face in bm.faces if face.select]
    verts_selected = list(set(vert for face in faces_selected for vert in face.verts))

    return faces_selected, verts_selected

