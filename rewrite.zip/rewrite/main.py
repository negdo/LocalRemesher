import bpy
import bmesh
import numpy as np
import mathutils
from scipy.optimize import linear_sum_assignment

from .selection_utils import *
from other_utils import *

############## INIT ###################

# set mode to object mode
bpy.ops.object.mode_set(mode='OBJECT')

# init bmesh objects
me = bpy.context.object.data
bm = bmesh.new()
bm.from_mesh(me)
bm_for_convex = bmesh.new()
bm_for_convex.from_mesh(me)


############## SELECTION ##############

# get selected faces and their vertices
faces_selected, verts_selected = get_selected(bm)

# make the selection convex
select_faces_inside_convex_hull(bm_for_convex, verts_selected, bm)












############## END ###################

# update bmesh
bm.to_mesh(me)
bm.free()
bm_for_convex.free()
bpy.ops.object.mode_set(mode='EDIT')












