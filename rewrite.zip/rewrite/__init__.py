bl_info = {
    "name": "Local Remesh",
    "author": "Your Name Here",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Add > Mesh > New Object",
    "description": "Adds a new Mesh Object",
    "warning": "",
    "doc_url": "",
    "category": "Add Mesh",
}


import bpy


def register():
    pass


def unregister():
    pass


if __name__ == "__main__":
    register()
